All six data sources have separate derived reports. Five completed processing. DriveDNA access remains pending. All fitted candidates were rejected.
The source reports preserve attribution and dataset licences. Bulk source datasets are excluded. No original dataset licence is replaced by the package licence.
Acquisition manifests retain provider URLs and byte hashes. Acquisition scripts are the exact local acquisition tools. Provider metadata is included beside them.
The MPDB report contains derived channel epoch onset measurements. It preserves censoring, competing event handling, and unverified units. It cannot validate absolute muscle force.
