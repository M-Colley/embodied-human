"""Acquire public empirical data without executing any source scripts."""

from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).resolve().parent
REVISION = "ffd7c36b00a58351653ab40238531cf2a89fcf52"


def acquire(url, target, size, *, git_sha=None, md5=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    if not target.resolve().is_relative_to(ROOT):
        raise ValueError("Target escapes the acquisition directory")
    last_error = None
    for attempt in range(3):
        try:
            part = target.with_suffix(target.suffix + ".part")
            if target.exists() and target.stat().st_size == size:
                candidate = target
            else:
                request = urllib.request.Request(
                    url, headers={"User-Agent": "myosuite-carla-empirical-research/0.1"}
                )
                with urllib.request.urlopen(request, timeout=45) as response:
                    with part.open("wb") as stream:
                        while block := response.read(1024 * 1024):
                            stream.write(block)
                            if stream.tell() > size:
                                raise ValueError("File exceeds expected size")
                candidate = part
            if candidate.stat().st_size != size:
                raise ValueError("File differs from expected size")
            digest = hashlib.sha256()
            md5_digest = hashlib.md5()
            blob = hashlib.sha1(f"blob {size}\0".encode())
            with candidate.open("rb") as stream:
                while block := stream.read(1024 * 1024):
                    digest.update(block)
                    md5_digest.update(block)
                    blob.update(block)
            if git_sha and blob.hexdigest() != git_sha:
                raise ValueError("Git blob checksum mismatch")
            if md5 and md5_digest.hexdigest() != md5:
                raise ValueError("Figshare MD5 checksum mismatch")
            if candidate != target:
                candidate.replace(target)
            return {
                "status": "downloaded", "url": url,
                "path": str(target.relative_to(ROOT)), "bytes": size,
                "sha256": digest.hexdigest(), "md5": md5_digest.hexdigest(),
                "git_blob_sha1": blob.hexdigest() if git_sha else None,
            }
        except Exception as error:
            last_error = f"{type(error).__name__}: {error}"
            time.sleep(attempt + 1)
    return {"status": "failed", "url": url, "path": str(target), "error": last_error}


def main():
    tree = json.loads((ROOT / "expert-tree.json").read_text())
    prefixes = (
        "Dataset/1-TrafficRecorder/", "Dataset/2-CANBus/",
        "Dataset/3-Driver/2-EyeTracking/", "Dataset/3-Driver/3-EDA/Timestamp/",
        "Dataset/3-Driver/5-Scale/",
    )
    selected = [
        item for item in tree["tree"] if item["type"] == "blob"
        and item["path"].startswith(prefixes)
        and item["path"].lower().endswith((".csv", ".json", ".txt"))
    ]
    report = {
        "started_utc": datetime.now(timezone.utc).isoformat(),
        "expert_revision": REVISION,
        "expert_selected_files": len(selected),
        "expert_selected_bytes": sum(item["size"] for item in selected),
        "files": [],
    }
    (ROOT / "acquisition-manifest.json").write_text(json.dumps(report, indent=2))
    with ThreadPoolExecutor(max_workers=7) as pool:
        jobs = {
            pool.submit(
                acquire,
                "https://raw.githubusercontent.com/AIR-DISCOVER/ExpertDrivingDataset/"
                + REVISION + "/" + item["path"],
                ROOT / "expert-driving" / item["path"], item["size"],
                git_sha=item["sha"],
            ): item["path"] for item in selected
        }
        mpdb = json.loads((ROOT / "mpdb-processed.json").read_text())["files"][1]
        jobs[pool.submit(
            acquire, mpdb["download_url"], ROOT / "mpdb" / "processed-additional.rar",
            mpdb["size"], md5=mpdb["computed_md5"],
        )] = "MPDB processed additional"
        for index, completed in enumerate(as_completed(jobs), 1):
            result = completed.result()
            report["files"].append(result)
            if index % 30 == 0 or result["status"] != "downloaded" or "mpdb" in result["path"].lower():
                print(f"Completed {index}/{len(jobs)}: {result['path']} ({result['status']})", flush=True)
                (ROOT / "acquisition-manifest.json").write_text(json.dumps(report, indent=2))
    report["finished_utc"] = datetime.now(timezone.utc).isoformat()
    report["failed_files"] = sum(item["status"] != "downloaded" for item in report["files"])
    (ROOT / "acquisition-manifest.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ("expert_selected_files", "expert_selected_bytes", "failed_files")}))


if __name__ == "__main__":
    main()
