"""Safely extract public EMG files and record the observed EEGLAB schema."""
from collections import Counter
import hashlib
import json
import ntpath
from pathlib import Path
import subprocess

import numpy as np
from scipy.io import loadmat

ROOT = Path(__file__).resolve().parent / "mpdb"


def main():
    output = ROOT / "sets"
    for label in ("additional", "main"):
        archive = ROOT / f"processed-{label}.rar"
        listing = subprocess.check_output([
            "C:/Program Files/7-Zip/7z.exe", "l", "-slt", "-ba", str(archive)
        ], text=True, encoding="utf-8", errors="strict")
        (ROOT / f"{label}-archive-list.txt").write_text(listing, encoding="utf-8")
        for line in listing.splitlines():
            if line.startswith("Path = "):
                name = line[7:]
                if ntpath.isabs(name) or ":" in name or ".." in Path(name).parts:
                    raise ValueError("Unsafe archive member")
                if not (output / name).resolve().is_relative_to(output):
                    raise ValueError("Archive member escapes the extraction directory")
            if line.startswith(("Symbolic Link = ", "Hard Link = ")):
                if line.split("=", 1)[1].strip():
                    raise ValueError("Archive links are unsupported")
        subprocess.run([
            "C:/Program Files/7-Zip/7z.exe", "x", str(archive),
            "-o" + str(output), "-y", "-ir!EMG*.set",
        ], check=True, stdout=subprocess.DEVNULL)
    records = []
    for path in sorted(output.rglob("EMG*.set")):
        content = loadmat(path, simplify_cells=True)
        eeg = content.get("EEG", content)
        data = np.asarray(eeg["data"])
        epochs = eeg["epoch"]
        epochs = epochs if isinstance(epochs, list) else [epochs]
        counts = Counter()
        ambiguous = []
        for index, epoch in enumerate(epochs):
            types = np.atleast_1d(epoch["eventtype"])
            latencies = np.atleast_1d(epoch["eventlatency"]).astype(float)
            centers = np.flatnonzero(np.isclose(latencies, 0.0, atol=1e-8))
            if len(centers) == 1:
                counts[str(types[centers[0]])] += 1
            else:
                counts["ambiguous_center"] += 1
            if len(types) > 1:
                ambiguous.append({
                    "epoch_zero_based": index, "event_types": types.tolist(),
                    "event_latencies_ms": latencies.tolist(),
                })
        records.append({
            "path": str(path), "sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
            "subject_id": path.stem.removeprefix("EMG_"),
            "channels": int(eeg["nbchan"]), "samples_per_epoch": int(eeg["pnts"]),
            "epochs": int(eeg["trials"]), "sampling_hz": float(eeg["srate"]),
            "xmin_s": float(eeg["xmin"]), "xmax_s": float(eeg["xmax"]),
            "channel_labels": [channel["labels"] for channel in eeg["chanlocs"]],
            "units": "unverified", "all_samples_finite": bool(np.isfinite(data).all()),
            "event_counts": dict(counts), "multiple_events": ambiguous,
        })
    totals = Counter()
    for record in records:
        totals.update(record["event_counts"])
    summary = {
        "subjects": len(records), "epochs": sum(item["epochs"] for item in records),
        "all_samples_finite": all(item["all_samples_finite"] for item in records),
        "event_counts": dict(totals), "records": records,
    }
    (ROOT / "emg-acquired-schema.json").write_text(json.dumps(summary, indent=2) + "\n")
    print(json.dumps({key: value for key, value in summary.items() if key != "records"}))


if __name__ == "__main__":
    main()
