"""Download a public Figshare archive through verified resumable ranges."""
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import sys
import time
import urllib.request

ROOT = Path(__file__).resolve().parent


def main():
    index = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    item = json.loads((ROOT / "mpdb-processed.json").read_text())["files"][index]
    destination = ROOT / "mpdb" / ("processed-additional.rar" if index else "processed-main.rar")
    destination.parent.mkdir(parents=True, exist_ok=True)
    if destination.exists() and destination.stat().st_size == item["size"]:
        digest = hashlib.md5()
        with destination.open("rb") as stream:
            while block := stream.read(1024 * 1024):
                digest.update(block)
        if digest.hexdigest() == item["computed_md5"]:
            print(f"Verified existing archive: {destination}", flush=True)
            return
    chunks = destination.parent / (destination.name + ".chunks")
    chunks.mkdir(exist_ok=True)
    size = item["size"]
    width = 4 * 1024 * 1024

    def download(start):
        end = min(size, start + width) - 1
        target = chunks / f"{start:012d}.chunk"
        expected = end - start + 1
        if target.exists() and target.stat().st_size == expected:
            return target
        for attempt in range(4):
            try:
                request = urllib.request.Request(item["download_url"], headers={
                    "Range": f"bytes={start}-{end}",
                    "User-Agent": "myosuite-carla-empirical-research/0.1",
                })
                with urllib.request.urlopen(request, timeout=30) as response:
                    if response.status != 206 or response.headers.get("Content-Range") != f"bytes {start}-{end}/{size}":
                        raise ValueError("Server did not return the requested byte range")
                    data = response.read(expected + 1)
                if len(data) != expected:
                    raise ValueError("Range length mismatch")
                partial = target.with_suffix(".part")
                partial.write_bytes(data)
                partial.replace(target)
                return target
            except Exception:
                if attempt == 3:
                    raise
                time.sleep(attempt + 1)

    starts = list(range(0, size, width))
    with ThreadPoolExecutor(max_workers=8) as pool:
        jobs = [pool.submit(download, start) for start in starts]
        for i, completed in enumerate(as_completed(jobs), 1):
            completed.result()
            if i % 16 == 0 or i == len(jobs):
                print(f"MPDB ranges {i}/{len(jobs)}", flush=True)
    md5 = hashlib.md5()
    sha256 = hashlib.sha256()
    temp = destination.with_suffix(".joined")
    with temp.open("wb") as output:
        for start in starts:
            data = (chunks / f"{start:012d}.chunk").read_bytes()
            md5.update(data)
            sha256.update(data)
            output.write(data)
    if md5.hexdigest() != item["computed_md5"]:
        raise ValueError("Joined archive differs from the Figshare MD5 checksum")
    temp.replace(destination)
    report = {
        "finished_utc": datetime.now(timezone.utc).isoformat(),
        "url": item["download_url"], "path": str(destination),
        "bytes": size, "md5": md5.hexdigest(), "sha256": sha256.hexdigest(),
        "source_licence": "CC BY 4.0", "range_bytes": width,
    }
    destination.with_suffix(".download.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report), flush=True)


if __name__ == "__main__":
    main()
